import styled from 'styled-components';

export const Wrapper = styled.div`
  .main-navcontainer {
    justify-content: end !important;
  }.field-container{
    display:flex;
  }
`;