

export const fildDropDown = [
  { id: 1, name: "Created By" },
  { id: 2, name: "Created Date" },
  { id: 3, name: "Modify By" },
  { id: 4, name: "Modify Date" },
  { id: 5, name: "Priority" },
  { id: 6, name: "Tag" },
  { id: 7, name: "Area" },
  { id: 8, name: "Type" },
];

export const oredrBy = [
  { id: 1, name: "Title" },
  { id: 2, name: "Owner" },
  { id: 3, name: "Modified" },
  { id: 4, name: "Created" },
];

export const groupBy = [
  { id: 1, name: "Owner" },
  { id: 2, name: "Area" },
  { id: 3, name: "Type" },
];
